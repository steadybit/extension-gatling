package example.constants;

public class Constants {
	public static final int EXPECTED_STATUS_CODE = 200;
}
